//multiline using battic
let a=`keandrapara,
mahakalpara,
nit college,
pin-754224`;
console.log(a);