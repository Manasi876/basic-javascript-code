let person={
    
    age:19,
    branch:"cst",
    sec:"c"
    
}
console.log(person);

//p1
for(let i=0;i<=10;i++){
    if(i===5){
        break
    }
    console.log(i);

}

