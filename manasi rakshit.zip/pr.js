let i=1;
let v=(++i+i--);
let h=((++i+i--)-i);
let z=(i--+i++);
console.log(v);
console.log(h);
console.log(z);