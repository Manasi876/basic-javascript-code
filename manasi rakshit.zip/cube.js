const volumeArrow =num =>num*num*num;
console.log(volumeArrow(3));



 import {add,substraction}from "../calculatear.js";
 console.log(add(3,5));
 console.log(substraction(3,5));