//store the value of array
let a=[];
for(i=51;i<=99;i++){
    if(i%2!==0){
        console.log(i);
        a.push(i);
    }
}
console.log(a);