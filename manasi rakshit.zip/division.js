//divide by 3,5 and not divide by 10

let x=15;
if(x%3===0 && x%5===0 && x%10!==0){
    console.log("true");
}