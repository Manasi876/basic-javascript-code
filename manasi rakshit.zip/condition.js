let x="manasi",
y="swapna",
z="manasi"
if(x==y){
    console.log("1");

}else if(x==z){
    console.log("1");
}else{
    console.log("0");
}