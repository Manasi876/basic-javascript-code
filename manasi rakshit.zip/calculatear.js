
 export function subtraction (a,b){
    return a-b;
}
console.log(subtraction(46,77));
 export const addition= function(a,b){
    return a+b;

}
console.log(addition(34,5));



/*const multiplicationArrow=(a,b)=>a*b;
console.log(multiplication(3,5));



const divisionArrow= (a,b)=>{
    return a/b;
}
console.log(division(10,2));*/
