let per={ a:1,b:2}
let per1={b:2,c:3}
let per2={c:5,d:6}
let pp={...per,...per2,e:9}
console.log(pp);