let marks=[97,66,75,89];
console.log(marks);
console.log(marks.length);