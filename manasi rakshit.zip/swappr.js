//swap dont use 3rd variable
let a=5;
b=7;
a=a+b;//5+7=12
 b=a-b;//12-7=5
 a=a-b;//12-5=7
console.log(a,b);

//swap using
let x=10, y=20;
[x,y]=[y,x]
console.log(x,y);


