let count=1;
function Counter(){
    for(let i=0;i<=20;i++){
        count++;
 
   }
   console.log(count);
}
Counter(12);
