const getpi = () => console.log("3.14");
getpi();