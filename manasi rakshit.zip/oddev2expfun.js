 //using function check odd even
 const CheckoddEven=function (i){
    if(i%2===0){
        
        console.log("even")
    }else{
        console.log("odd")
    }
}
CheckoddEven(77);
