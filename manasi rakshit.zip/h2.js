//skip 6 in series 1 to 10
for(i=0;i<=10;i++){
    if(i==6){
        continue;
    }
    console.log(i);
}