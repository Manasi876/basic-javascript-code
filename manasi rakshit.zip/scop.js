//scope using
let a=5;
{
    console.log("outer");
    {
        console.log("inner");
        {
            console.log("inner core");
        }
    }
}