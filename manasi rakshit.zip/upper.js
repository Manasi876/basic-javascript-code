//upper case
function greet(name){
    return `HELLO ${name.toUpperCase()}`;
}
console.log(greet("manasi rakshit"));