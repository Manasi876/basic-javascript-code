// table for 9
for( let i=1;i<=20;i++){
    console.log(`9 x ${i}:`,9*i);
    console.log(`9 x ${i}:=${9*i}`);
}