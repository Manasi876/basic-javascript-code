//using loop
let sum=0;
for(let i=1;i<=15;i++){
    sum += i;
    console.log(sum);

}
//console.log(sum);
