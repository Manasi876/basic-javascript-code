//using function check greater
function chekgreater(a,b,c){
    if(a>=b && a>=c){
        console.log(" a grater");
    }else if(b>=a && b>=c){
        console.log(" b grearer");

    }else {
        console.log(" c is greater");
    }
}
chekgreater(77,98,64)