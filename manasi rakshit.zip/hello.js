//simple js code
let x=5;
x+=5;
console.log(x);


